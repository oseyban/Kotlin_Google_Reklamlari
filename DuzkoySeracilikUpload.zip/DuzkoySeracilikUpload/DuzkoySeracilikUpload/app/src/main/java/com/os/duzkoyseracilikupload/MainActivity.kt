package com.os.duzkoyseracilikupload

import android.annotation.SuppressLint
import android.content.Intent
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import android.widget.Button
import android.widget.TextView

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import android.widget.Toast
import com.google.android.gms.ads.MobileAds.*
import com.os.duzkoyseracilikupload.databinding.ActivityMainBinding

import java.util.Locale

// Remove the line below after defining your own ad unit ID.
//private const val TOAST_TEXT = "Devam etmek için reklamı kapatın lütfen "
private const val START_LEVEL = 1

class MainActivity : AppCompatActivity() {

    private var currentLevel: Int = 0
    private var interstitialAd: InterstitialAd? = null
    private lateinit var nextLevelButton: Button
    private lateinit var levelTextView: TextView
    private val TAG = "MainActivity"
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initialize(this) { }
        loadInterstitialAd()


        nextLevelButton = binding.nextLevelButton
        nextLevelButton.isEnabled = false
        nextLevelButton.setOnClickListener { showInterstitial() }

        levelTextView = binding.level
        currentLevel = START_LEVEL
    }

    private fun loadInterstitialAd() {
        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(this, getString(R.string.interstitial_ad_unit_id), adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    nextLevelButton.isEnabled = true
                    Toast.makeText(this@MainActivity, "Yükleniyor", Toast.LENGTH_SHORT)
                        .show()
                    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            interstitialAd = null
                            Log.d(TAG, "Reklam Geçiliyor...")
                            // Reklam kapatıldıktan sonra VideoYukleActivity'ye geçiş yap
                            //goToNextLevel()
                            val intent = Intent(applicationContext, VideoYukleActivity::class.java)
                            startActivity(intent)
                        }

                        override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                            interstitialAd = null
                            Log.d(TAG, "Reklam Gösterilemiyor...")
                        }

                        override fun onAdShowedFullScreenContent() {
                            Log.d(TAG, "Reklam Sonrası devam edebileceksiniz...")
                        }
                    }
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    Log.i(TAG, loadAdError.message)
                    interstitialAd = null
                    nextLevelButton.isEnabled = true
                    val error: String = String.format(
                        Locale.ENGLISH,
                        "domain: %s, code: %d, message: %s",
                        loadAdError.domain,
                        loadAdError.code,
                        loadAdError.message
                    )
                    Toast.makeText(
                        this@MainActivity,
                        "Reklam Yüklem Hatası: $error", Toast.LENGTH_SHORT
                    )
                        .show()
                }
            })
    }

    private fun showInterstitial() {
        if (interstitialAd != null) {
            interstitialAd!!.show(this)
        } else {
            println(interstitialAd)
            Toast.makeText(this, "Lütfen internetinizin açık olduğundan emin olun", Toast.LENGTH_SHORT).show()
            goToNextLevel()
        }
    }

    @SuppressLint("SetTextI18n")
    private fun goToNextLevel() {
        println("go to next level")
        println(currentLevel)

        levelTextView.text = "Level " + (++currentLevel)
        if (interstitialAd == null) {
            loadInterstitialAd()
            println("if interstitial=null")
        }
        if (currentLevel == 1) {
            println("if currentLevel=1")
            // Reklam kapatıldıktan sonra VideoYukleActivity'ye geçiş yap
            val intent = Intent(applicationContext, VideoYukleActivity::class.java)
            startActivity(intent)
        }
    }
}
