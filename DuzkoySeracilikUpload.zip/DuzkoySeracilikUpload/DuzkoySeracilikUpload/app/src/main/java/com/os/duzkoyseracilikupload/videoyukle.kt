package com.os.duzkoyseracilikupload
import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore
import com.os.duzkoyseracilikupload.databinding.VideoyukleBinding

class VideoYukleActivity : AppCompatActivity() {

    private lateinit var binding: VideoyukleBinding
    var db=FirebaseFirestore.getInstance()

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // videoyukle.xml dosyasını bağla (inflate) et
        binding = VideoyukleBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        val deneme=findViewById<TextView>(R.id.textView)
        deneme.text="Video Yükleme Ekranı-1"

        // Video yükleme ekranı ile ilgili diğer işlemleri burada yapabilirsiniz.

    }
    fun upload(){


    }
    fun kaydet(){

    }
}
